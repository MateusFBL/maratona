#include <stdio.h>

int main() {
    int N, P, Q;
    char op;


    scanf("%d", &N);
    scanf("%d %c %d", &P, &op, &Q);


    if (op == '+') {
        if (P > N - Q) {
            printf("OVERFLOW\n");
        } else {
            printf("OK\n");
        }
    } else if (op == '*') {
        if (P > N / Q) {
            printf("OVERFLOW\n");
        } else {
            printf("OK\n");
        }
    }

    return 0;
}
