#include <stdio.h>
#include <stdlib.h>


int main() {
    int N, K;
    scanf("%d %d", &N, &K);

    int* seq = (int*)malloc(N * sizeof(int));

    for (int i = 0; i < N; i++) {
        scanf("%d", &seq[i]);
    }

    int* prefixSum = (int*)calloc((N + 1), sizeof(int));
    int ret = 0;

    for (int i = 1; i <= N; i++) {
        prefixSum[i] = prefixSum[i - 1] + seq[i - 1];
    }

    for (int i = 1; i <= N; i++) {
        for (int j = i; j <= N; j++) {
            int sum = prefixSum[j] - prefixSum[i - 1];
            if (sum == K) {
                ret++;
            }
        }
    }

    printf("%d\n", ret);

    free(seq);
    free(prefixSum);

    return 0;
}
