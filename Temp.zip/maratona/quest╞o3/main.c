#include <stdio.h>
#include <stdlib.h>

int main()
{

    int N;
    scanf("%d", &N);

    int scores[101] = {0};

    for (int i = 0; i < N; i++) {
        int nota;
        scanf("%d", &nota);
        scores[nota]++;
    }

    int freqScore = 0;
    int maxFreq = 0;

    for (int i = 0; i <= 100; i++) {
        if (scores[i] >= maxFreq) {
            maxFreq = scores[i];
            freqScore = i;
        }
    }

    printf("%d", freqScore);

    return 0;
}
