#include <stdio.h>
#include <stdlib.h>


int main()
{
    int linha, col;
    scanf("%d %d", &linha, &col);

    int mat[linha][col];

    for (int i = 0; i < linha; i++)
    {
        for (int j = 0; j < col; j++)
        {
            scanf("%d", &mat[i][j]);
        }
    }

    int simBool = 1;
    for (int i = 0; i < linha; i++)
    {
        for (int j = 0; j < col; j++)
        {
            if (mat[i][j] != mat[j][i])
            {
                simBool = 0;
                break;
            }
        }
        if (!simBool)
        {
            break;
        }
    }

    if (simBool)
    {
        printf("1\n");
    }
    else
    {
        printf("0\n");
    }

    return 0;
}
