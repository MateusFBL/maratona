#include <stdio.h>
#include <stdlib.h>

int main()
{

    int matricula[1000];
    int nota[1000];
    int i = 0;

    while(1)
    {
        scanf("%d", &matricula[i]);
        scanf("%d", &nota[i]);
        if (matricula[i] == 0)
        {
            break;
        }
        i++;
    }

    for(int j = 0; j <= i; j++)
    {
        if( nota[j] >= 80)
        {
            printf("%d %d\n", matricula[j], nota[j]);
        }
    }
}
