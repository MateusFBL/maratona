#include <stdio.h>

int main() {
    float vc, vb;
    int n;


    scanf("%f", &vc);
    scanf("%f", &vb);


    scanf("%d", &n);

    float total = vc + vb;


    int consumo[n];


    for (int i = 0; i < n; i++) {
        scanf("%d", &consumo[i]);
    }


    float valorPorPessoa[n];


    for (int i = 0; i < n; i++) {
        if (consumo[i] == 0) {
            valorPorPessoa[i] = 0;
        } else if (consumo[i] == 1 || consumo[i] == 3) {
            valorPorPessoa[i] = vc;
        } else if (consumo[i] == 2 || consumo[i] == 3) {
            valorPorPessoa[i] = vb;
        }
    }


    printf("%.2f\n", total);


    for (int i = 0; i < n; i++) {
        printf("%.2f\n", valorPorPessoa[i]);
    }

    return 0;
}
